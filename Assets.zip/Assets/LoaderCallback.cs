using UnityEngine;

public class LoaderCallback : MonoBehaviour
{    
    void LateUpdate()
    {
        SceneLoader.LoaderCallback();
    }
}
