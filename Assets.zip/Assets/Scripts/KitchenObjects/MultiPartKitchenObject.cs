public class MultiPartKitchenObject : KitchenObject
{

}