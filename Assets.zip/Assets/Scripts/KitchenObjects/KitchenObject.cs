using System;
using System.Collections.Generic;
using System.Linq;
using Unity.VisualScripting;
using UnityEngine;

public class KitchenObject : MonoBehaviour, INode, IInteractable, ICombinable
{
    public KitchenObjectState prefab;
    [SerializeField] protected Transform visualParent;

    protected Transform currentVisual;
    protected Transform additionalVisual;
    protected float additionalVisualHeight;
    private Vector3 startPosition;

    static void UpdateAdditionVisual(Node<KitchenObject> node)
    {
        if (node == null 
            || node.Value == null
            || node.Value.additionalVisual == null)
            return;

        var additionalVisual = node.Value.additionalVisual;

        var position = additionalVisual.localPosition;
        position.y = node.CombinedSize - node.Value.additionalVisualHeight;
        additionalVisual.localPosition = position;
    }

    protected Rigidbody rb;

    protected Collider[] originColliders;
    protected List<Collider> meshColliders;

    public event Action Interacted;
    public event Action PreppedToInteract;

    public ProductState CurrentState => prefab.State;
    public ProductType ProductType => prefab.ProductType;

    public Node<KitchenObject> Node { get; private set; }

    private bool isHeld;
    public bool IsHeld
    {
        get => isHeld;
        set
        {
            isHeld = value;
            foreach (var collider in meshColliders)
                collider.enabled = !isHeld;
            if (!isHeld && rb == null)
                AddRigidBody(false);

            rb.isKinematic = isHeld;
            transform.rotation = Quaternion.identity;
        }
    }

    private bool initited = false;

    void Start()
    {
        Initiate();
    }

    void Initiate()
    {
        if (!initited)
        {
            meshColliders ??= new List<Collider>(4);

            var recipe = prefab.CombiningRecipe;
            if (recipe == null)
                Node = new Node<KitchenObject>(this, transform, 0);
            else              
                Node = new Node<KitchenObject>(this, transform, recipe.Capacity, recipe.HierarchyPriority);

            void updateState(Transform parent)
                => IsHeld = parent != null;

            Node.ParentChanged += updateState;
            initited = true;
        }
    }

    public void UpdateState(KitchenObjectState scriptableObject)
    {
        prefab = scriptableObject;
        UpdateVisual();
    }

    protected void UpdateVisual()
    {
        if (currentVisual?.gameObject != null)
            Destroy(currentVisual.gameObject);

        currentVisual = Instantiate(prefab.Model, visualParent).transform;
        currentVisual.localPosition = Vector3.zero;
        currentVisual.rotation = Quaternion.identity;

        void UpdateMeshColliders(Transform container)
        {
            var isHeld = IsHeld;
            meshColliders.RemoveAll(x => originColliders.Contains(x));
            originColliders = container.GetComponentsInChildren<Collider>();
            meshColliders.AddRange(originColliders);
            IsHeld = isHeld;
        }

        UpdateMeshColliders(currentVisual);

        var bounds = new Bounds();
        foreach(var collider in meshColliders)
        {
            bounds.Encapsulate(collider.bounds);
        }
        Node.SelfSize = bounds.size.y - transform.position.y;

        var offset = Node.Offset;
              
        if(currentVisual.TryGetComponent<MultiVisual>(out var multi))
        {
            additionalVisual = multi.parts[1].transform;
            additionalVisualHeight = multi.parts[1].GetComponentInChildren<Collider>().bounds.size.y;
            startPosition = additionalVisual.localPosition;

            offset.y = multi.parts[0].GetComponentInChildren<Collider>().bounds.size.y;
        }
        else
            offset.y = Node.SelfSize;

        Node.Offset = offset;
    }

    public static KitchenObject SpawnProduct(KitchenObjectState scriptableObject, bool isHeld)
    {
        var productTemplate = AssetCollection.Instance.ProductTemplate;
        return Spawn(productTemplate, scriptableObject, isHeld);
    }

    private static KitchenObject Spawn(KitchenObject prefab, KitchenObjectState scriptableObject, bool isHeld)
    {
        var kitchenObject = Instantiate(prefab);
        kitchenObject.prefab = scriptableObject;
        kitchenObject.Initiate();
        kitchenObject.UpdateVisual();
        return kitchenObject;
    }

    public void Interact(Player source) => Interacted?.Invoke();
    public void PrepareToInteract() => PreppedToInteract?.Invoke();
    public void InteractAlternate(Player player) => Interacted?.Invoke();

    public bool IsOperationAvailable(OperationType type, KitchenObject kitchenObjects = null)
    {
        return prefab.Recipes.Any(x => x.OperationType == type)
            || kitchenObjects != null && kitchenObjects.prefab.Recipes.Any(x => x.OperationType == type);
    }

    public BaseRecipe GetRecipe(OperationType type)
        => prefab.Recipes.First(x => x.OperationType == type);

    public KitchenObject DoOperation(OperationType operationType)
    {
        if (!IsOperationAvailable(operationType))
            return this;

        switch (operationType)
        {
            case OperationType.Slicing:
            case OperationType.Cooking:
                Modify(operationType);
                break;
        }

        return this;
    }

    private void Modify(OperationType operationType)
    {
        var recipe = GetRecipe(operationType) as ModifyRecipe;
        UpdateState(recipe.Output);
    }

    public bool TryCombine(ICombinable addition, out ICombinable result)
    {
        result = this;
        if (addition is KitchenObject ko)
            return TryCombine(ko, out result);

        return false;
    }

    public bool TryCombine(KitchenObject addition, out KitchenObject result)
    {
        var source = this;
        result = this;

        if (source.prefab.CombiningRecipe == null && addition.prefab.CombiningRecipe == null
            || source.prefab == addition.prefab && !source.prefab.CombiningRecipe.WithItSelf)
            return false;

        (KitchenObject parent, KitchenObject child) =
            (source.Node.HierarchyPriority) <= (addition.Node.HierarchyPriority)
            ? (source, addition)
            : (addition, source);

        result = parent;

        if (!parent.Node.IsFreeSpace)
            return false;

        child.RemoveRigidBody();
        parent.Node.Push(child.Node);

        parent.meshColliders.AddRange(child.meshColliders);

        child.SyncMeshColliders(!parent.IsHeld);

        Node<KitchenObject>.ForEachDownward(parent.Node, UpdateAdditionVisual);

        return result;
    }

    private void SyncMeshColliders(bool state)
    {
        foreach (var item in meshColliders)
            item.enabled = state;
    }


    public void Divide()
    {
        var poppedChild = Node.Pop().Value;

        poppedChild.AddRigidBody(false);

        void CollectChildCollider(Node<KitchenObject> node)
        {
            foreach (var collider in node.Value.originColliders)
                if (!poppedChild.meshColliders.Contains(collider))
                    poppedChild.meshColliders.Add(collider);
        }

        Node<KitchenObject>.ForEachDownward(poppedChild.Node, CollectChildCollider);

        meshColliders.RemoveAll(x => poppedChild.meshColliders.Contains(x));

        var dropDirection = new Vector3(
            UnityEngine.Random.Range(-1.0f, 1.0f),
            0.5f,
            UnityEngine.Random.Range(-1.0f, 1.0f));

        poppedChild.rb.AddForce(4f * dropDirection, ForceMode.Impulse);

        poppedChild.SyncMeshColliders(!poppedChild.IsHeld);

        Node<KitchenObject>.ForEachDownward(Node, UpdateAdditionVisual);
    }

    public KitchenObject Combine(Player source, KitchenObject[] kitchenObject)
    {
        var result = this;
        for (int i = 0; i < kitchenObject.Length; i++)
            if (TryCombine(kitchenObject[i], out var newResult))
                result = newResult;

        return result;
    }

    public void AddRigidBody(bool isKinematic = true)
    {
        if (rb != null)
            return;

        rb = gameObject.AddComponent<Rigidbody>();
        rb.isKinematic = isKinematic;
        rb.useGravity = true;
    }

    public void RemoveRigidBody()
    {
        if (rb != null)
            Destroy(rb);
    }

    void OnDestroy()
    {
        Node.Parent?.Children.Remove(Node);
    }

    internal void DestroySelf()
    {
        Destroy(gameObject);
    }
}