using UnityEngine;

public interface INode
{
    public Transform transform { get; }
    public Node<KitchenObject> Node { get; }
}