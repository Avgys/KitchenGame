using System;
using System.Collections.Generic;
using System.Linq;
using Unity.VisualScripting;
using UnityEngine;
using static UnityEngine.Rendering.DebugUI;

#nullable enable
public class Node<T> where T : class, INode
{
    private Node<T>? parent;
    public Node<T>? Parent
    {
        get => parent;

        private set
        {
            parent = value;
            transform.parent = value?.transform;

            ParentChanged?.Invoke(value?.transform);
        }
    }
    public List<Node<T>>? Children { get; private set; }

    public T? Value { get; private set; }
    private readonly Transform transform;

    public Node<T>? LastItem => Children?.LastOrDefault();
    public Node<T>? FirstItem => Children?.FirstOrDefault();

    public float CombinedSize = 0f;
    private float selfSize;
    public float SelfSize
    {
        get => selfSize; 
        set
        {
            CombinedSize = CombinedSize - selfSize + value;
            selfSize = value;
        }
    }

    public bool IsEmpty => !Children?.Any() ?? true;
    public bool IsFreeSpace => Capacity > Children?.Count;

    //public event Action<Vector3> PositionChanged;
    public event Action<Transform?>? ParentChanged;

    private int capacity;
    public int Capacity
    {
        get => capacity;
        set
        {
            capacity = value;
            if (Children != null)
                Children.Capacity = value;
            else if (capacity > 0)
                Children = new List<Node<T>>(capacity);
        }
    }

    private Vector3 offset;
    public Vector3 Offset
    {
        get => offset;
        set
        {
            offset = value;
            if (!IsEmpty)
                UpdateChildrenPositions();
        }
    }

    private void UpdateChildrenPositions()
        => ForEachDownward(this, UpdateNodePosition);

    public byte HierarchyPriority { get; private set; }

    public Node(Transform transform, int capacity, byte priority = 127, Vector3 offset = default)
    {
        if (capacity > 0)
        {
            Children = new(capacity);
        }

        this.capacity = capacity;
        this.transform = transform;
        this.Offset = offset;
        HierarchyPriority = priority;
    }


    public Node(T value, Transform transform, int capacity, byte priority = 127, Vector3 offset = default)
        : this(transform, capacity, priority, offset)
    {
        Value = value;
    }

    public bool Push(Node<T> itemToAdd)
    {
        var result = PushRecursive(this, itemToAdd);

        static bool PushRecursive(Node<T> parent, Node<T> item)
        {
            if (!parent.IsFreeSpace && (parent.Children?.Count ?? 0) == 0)
                return false;

            if (parent.Children != null)
                for (int i = parent.Children.Count - 1; i >= 0; i--)
                {
                    var child = parent.Children[i];
                    if (child.IsFreeSpace && child.HierarchyPriority < item.HierarchyPriority)
                        return PushRecursive(child, item);
                }

            item.RemoveFromParent();
            parent.Children!.Add(item);
            item.Parent = parent;

            static void ModifySizeUpwards(Node<T> startNode, float size)
            {
                var parentNode = startNode;
                while (parentNode != null)
                {
                    parentNode.CombinedSize += size;
                    parentNode = parentNode.Parent;
                }
            }

            ModifySizeUpwards(parent, item.CombinedSize);

            return true;
        }

        ForEachDownward(this, UpdateNodePosition);
        //addedQueue!.Add(item);

        return result;
    }

    private void RemoveFromParent()
    {
        if (Parent != null)
        {
            Parent.Children!.Remove(this);
            Parent.CombinedSize -= CombinedSize;
        }
    }

    public IEnumerable<Node<T>> Flatten()
    {
        var nodes = new List<Node<T>>();

        FlatRecursive(this);

        void FlatRecursive(Node<T> node)
        {
            nodes.Add(node);
            if (node.Children != null)
                foreach (var item in node.Children)
                {
                    FlatRecursive(item);
                }
        }

        return nodes;
    }

    public Node<T>? Pop(bool PopLastItem = false)
    {
        if (IsEmpty)
            return null;

        Node<T> result;

        if (PopLastItem)
        {
            static Node<T> PopRecursive(Node<T> holder)
                 => holder.IsEmpty ? holder : PopRecursive(holder.Children.Last());

            result = PopRecursive(Children.Last());
        }
        else
        {
            result = Children.Last();
        }

        result.RemoveFromParent();
        result.Parent = null;

        return result;
    }

    public void SwapChildren(Node<T> secondParent)
    {
        var sizeOfFirstChildren = Children.Sum(child => child.CombinedSize);
        var sizeOfFSecondChildren = secondParent.Children.Sum(child => child.CombinedSize);

        (secondParent.Children, Children) = (Children, secondParent.Children);

        CombinedSize = CombinedSize - sizeOfFirstChildren + sizeOfFSecondChildren;
        secondParent.CombinedSize = secondParent.CombinedSize + sizeOfFirstChildren - sizeOfFSecondChildren;

        static void UpdateChildrenParent(Node<T> parentNode)
        {
            if (parentNode.Children!.Count > 0)
                foreach (var child in parentNode.Children)
                    child.Parent = parentNode;
        }

        UpdateChildrenParent(this);
        UpdateChildrenPositions();

        UpdateChildrenParent(secondParent);
        secondParent.UpdateChildrenPositions();
    }

    private static void UpdateNodePosition(Node<T> node)
    {
        if (node.Parent == null)
            return;

        static Vector3 getOffsetFromPrevChild(Node<T> node)
        {
            var parent = node.Parent;

            if (parent == null)
                return Vector3.zero;

            var childIndex = parent.Children!.IndexOf(node);

            if (parent.Children!.Count == 1
                || childIndex == 0)
                return parent.Offset;

            var previousChild = parent.Children[childIndex - 1];

            var additionOffset = new Vector3(0, previousChild.CombinedSize);
            return previousChild.transform.localPosition + additionOffset;
        }

        var offset = getOffsetFromPrevChild(node);

        node.transform.localPosition = offset;
    }

    internal void ReplaceLastItemWith(Node<T> ko)
    {
        Pop();
        Push(ko);
    }

    internal static void ForEachUpward(Node<T> startNode, Action<Node<T>> action)
    {
        UpdateTreeRecursive(startNode);

        void UpdateTreeRecursive(Node<T> node)
        {
            if (node == null) return;
            action(node);

            if (node.Parent != null)
                UpdateTreeRecursive(node.Parent);
        }
    }

    internal static void ForEachDownward(Node<T> startNode, Action<Node<T>> action)
    {
        UpdateTreeRecursive(startNode);

        void UpdateTreeRecursive(Node<T> node)
        {
            if (node == null) return;
            action(node);

            if (node.Children != null)
                foreach (var item in node.Children)
                    UpdateTreeRecursive(item);
        }
    }
}