using UnityEngine;

public class LookAt : MonoBehaviour
{
    private void LateUpdate()
    {
        transform.LookAt(2 * transform.position - Camera.main.transform.position);
    }
}
