using UnityEngine;

public class MultiVisual : MonoBehaviour
{
    public Transform[] parts;
}
