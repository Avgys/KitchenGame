using JetBrains.Annotations;
using System;
using System.Collections.Generic;
using System.Linq;
using Unity.VisualScripting;
using UnityEngine;

#nullable enable
#pragma warning disable CS8618

public class DeliveryManager : MonoBehaviour
{
    private struct AccountedDish
    {
        public AccountedDish(KitchenObjectState state, int count)
        {
            State = state;
            Count = count;
        }

        public KitchenObjectState State;
        public int Count;
    }

    public static DeliveryManager Instance { get; private set; }

    [SerializeField] private DishCatalog Catalog;

    private List<Dish> awaitingDishes;

    [SerializeField] private int waitingMaxDishes = 4;
    public int WaitingDishesMax => waitingMaxDishes;

    [SerializeField] private float spawnTimeDelay = 4f;
    private float timeToSpawn;
    private bool spawning;

    private void Awake() => Instance = this;

    public event Action<DeliveryManager, Dish> DishRequested;
    public event Action<DeliveryManager> WrongDishServed;
    public event Action<DeliveryManager, Dish> DishServed;

    public int TotalDishServed { get; private set; } = 0;

    private void Start()
    {
        awaitingDishes = new();

        GameManager.Instance.StateChanged += Instance_StateChanged;
    }

    private void Instance_StateChanged(GameManager.State obj) 
        => spawning = obj == GameManager.State.GamePlaying;

    private void Update()
    {
        if (!spawning)
            return;

        timeToSpawn -= Time.deltaTime;
        if (timeToSpawn < 0 && awaitingDishes.Count < waitingMaxDishes)
        {
            void SpawnDish()
            {
                var index = UnityEngine.Random.Range(0, Catalog.Dishes.Length);
                var dish = Catalog.Dishes[index];
                var tries = 0;

                if (awaitingDishes.Count < Catalog.Dishes.Length)
                    while (awaitingDishes.Contains(dish) && tries < Catalog.Dishes.Length)
                    {
                        tries++;
                        dish = Catalog.Dishes[(tries + index) % Catalog.Dishes.Length];
                    }

                awaitingDishes.Add(dish);
                Debug.Log($"Added dish {dish.name}");
                DishRequested?.Invoke(this, dish);
            }

            SpawnDish();
            timeToSpawn = spawnTimeDelay;
        }
    }

    public bool TryDeliverDish(KitchenObject ko)
    {
        if (ko.ProductType != ProductType.Plate)
        {
            WrongDishServed?.Invoke(this);
            return false;
        }

        var flattenDish = ko.Node.Children
            .SelectMany(node => node.Flatten()
            .Select(x => x.Value!.prefab)).ToArray();

        var countedDish = CountComponents(flattenDish);

        var sameLengthDishes = awaitingDishes
            .Where(x => x.Ingredients.Length == flattenDish.Length)
            .Select(dish => (dish, CountComponents(dish.Ingredients)))
            .Where(x => x.Item2.Count == countedDish.Count)
            .ToArray();

        List<AccountedDish> CountComponents(IEnumerable<KitchenObjectState> mixedDish)
        {
            var list = new List<AccountedDish>();

            foreach (var component in mixedDish)
            {
                if (list.Any(x => x.State == component))
                {
                    var item = list.First(x => x.State == component);
                    item.Count++;
                }
                else
                    list.Add(new AccountedDish(component, 1));
            }

            return list;
        }

        Dish? FindSameDish(List<AccountedDish> dishToFind)
        {
            for (int i = 0; i < sameLengthDishes.Length; i++)
            {
                var dishVarian = sameLengthDishes[i];

                if (isEqual(dishVarian.Item2, countedDish))
                    return dishVarian.dish;
            }

            return null;

            bool isEqual(IEnumerable<AccountedDish> x, IEnumerable<AccountedDish> y)
            {
                foreach (var xItem in x)
                {
                    if (!y.Any(yItem => yItem.State == xItem.State && yItem.Count == xItem.Count))
                        return false;
                }

                return true;
            }
        }

        var dish = FindSameDish(countedDish);

        if (dish == null)
        {
            WrongDishServed?.Invoke(this);
            return false;
        }

        awaitingDishes.Remove(dish);

        TotalDishServed++;
        Debug.Log($"Dish delivered {dish.DishName}");
        DishServed?.Invoke(this, dish);
        return true;
    }
}
