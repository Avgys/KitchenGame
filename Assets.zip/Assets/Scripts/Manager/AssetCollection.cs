using System.Linq;
using UnityEngine;
using UnityMeshSimplifier;

public class AssetCollection : MonoBehaviour
{
    public static AssetCollection Instance { get; private set; }
    public KitchenObject ProductTemplate;
    //public KitchenObject PlateTemplate;
    [SerializeField] KitchenObjectSO[] ProductSubtypes;
    [SerializeField] RecipeCatalog RecipeCatalog;

    public MeshSimplifier meshSimplifier;

    private void Awake()
    {
        Instance = this;
        PrepareProducts();
    }

    private void PrepareProducts()
    {
        foreach (var product in ProductSubtypes)
        {
            product.Init(RecipeCatalog);
        }
    }

    internal KitchenObjectSO GetProduct(ProductType productType)
    {
        return ProductSubtypes.FirstOrDefault(x => x.ProductType == productType);
    }

    internal KitchenObjectState GetProductState(ProductType productType, ProductState productState)
    {
        return GetProduct(productType).States.FirstOrDefault(x => x.State == productState);
    }
}
