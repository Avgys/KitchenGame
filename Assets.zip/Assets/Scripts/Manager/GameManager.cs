using System;
using System.Collections.Generic;
using UnityEngine;
using static UnityEngine.InputSystem.InputAction;

public class GameManager : MonoBehaviour
{
    public enum State
    {
        WaitingToStart,
        CountdownToStart,
        GamePlaying,
        GameOver,
        Pause
    }

    public event Action<State> StateChanged;

    public static GameManager Instance { get; private set; }
    public float StartGameTimer => timers[State.CountdownToStart].currentTime;
    public Timer GameTimer => timers[State.GamePlaying];

    [SerializeField] private State currentState;
    private const int TIMERS_COUNT = 2;

    public class Timer
    {
        public float currentTime;
        public float maxTime;

        public Timer(float currentTimer, float maxTimer)
        {
            currentTime = currentTimer;
            maxTime = maxTimer;
        }

        public void Restart() => currentTime = maxTime;
        public void DecreaseTimer(float time) => currentTime -= time;
        public float Percentage => currentTime / maxTime;
    }

    private Dictionary<State, Timer> timers;

    [SerializeField] private float RoundTime = 120f;
    private State previousState;
    private bool isPaused = false;
    public event Action<bool> PauseToggled;

    private void Awake()
    {
        Instance = this;
        currentState = State.WaitingToStart;
        timers = new()
        {
            { State.WaitingToStart, new Timer(0f, 1f) },
            { State.CountdownToStart, new Timer(0f, 3f) },
            { State.GamePlaying, new Timer(0f, RoundTime) }
        };

        ResetTimers();
    }

    private void Start()
    {
        GameInput.Instance.Pause += (CallbackContext t) => ToggleGamePause();
        ChangeState(State.WaitingToStart);
    }

    public void ToggleGamePause()
    {
        isPaused = !isPaused;
        Time.timeScale = isPaused ? 0f : 1f;
        PauseToggled?.Invoke(isPaused);
    }

    private void ResetTimers()
    {
        foreach (var timer in timers.Values)
            timer.Restart();
    }

    private void Update()
    {
        HandleState();
    }

    private void HandleState()
    {
        bool CheckTimer(State state)
        {
            timers[state].DecreaseTimer(Time.deltaTime);
            if (timers[state].currentTime < 0f)
            {
                timers[state].Restart();
                return true;
            }

            return false;
        }

        switch (currentState)
        {
            case State.WaitingToStart:
                if (CheckTimer(currentState))
                    ChangeState(State.CountdownToStart);
                break;
            case State.CountdownToStart:
                if (CheckTimer(currentState))
                    ChangeState(State.GamePlaying);
                break;
            case State.GamePlaying:
                if (CheckTimer(currentState))
                    ChangeState(State.GameOver);
                break;
            case State.GameOver:
            case State.Pause:
                break;
        }
    }

    void ChangeState(State state)
    {
        currentState = state;
        StateChanged?.Invoke(state);
    }

    private void OnDestroy()
    {
        if (Instance == this)
            Instance = null;
    }
}