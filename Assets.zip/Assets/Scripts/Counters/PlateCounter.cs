using UnityEngine;

public class PlateCounter : BaseCounter
{
    [SerializeField] private float spawnTimer = 1f;

    [SerializeField] private KitchenObjectState platePrefab;

    private float currentTime;

    protected override void Start()
    {
        base.Start();
        Node.Capacity = 10;
    }

    protected void Update()
    {
        HandleSpawning();
    }

    private void HandleSpawning()
    {
        if (currentTime >= spawnTimer)
        {
            currentTime = 0;
            SpawnPlate();
        }

        currentTime += Time.deltaTime;
    }

    private void SpawnPlate()
    {
        if (!Node.IsFreeSpace)
            return;

        var kitchenObject = KitchenObject.SpawnProduct(platePrefab, false);
        Node.Push(kitchenObject.Node);
    }

    public override void Interact(Player source)
    {
        if (!Node.IsEmpty && source.Node.IsEmpty)
        {
            base.Interact(source);
            var addedItem = Node.Pop();
            addedItem.Value.AddRigidBody(true);
            source.Node.Push(addedItem);
        }
    }
}
