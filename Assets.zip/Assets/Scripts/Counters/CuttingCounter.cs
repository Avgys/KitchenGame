using System;
using UnityEditor;

public class CuttingCounter : BaseCounter, IProgress
{
    private float CutsToTake = float.Epsilon;
    private int CurrentCuts;
    public float Progress => CurrentCuts / CutsToTake;
    public event Action<float> ProgressChanged;
    public static event Action<CuttingCounter> OnAnyCut;
    public static void ResetStatic() => OnAnyCut = null;

    private const OperationType operationType = OperationType.Slicing;

    protected override void Start()
    {
        base.Start();

        ProgressChanged?.Invoke(Progress);
        //ProductChanged?.Invoke(productType, productState);
    }

    public override void Interact(Player source)
    {
        base.Interact(source);
        Node.SwapChildren(source.Node);

        ResetCuts();
    }

    void ResetCuts()
    {
        CurrentCuts = 0;
        CutsToTake = float.Epsilon;
        ProgressChanged?.Invoke(Progress);
    }

    public override void InteractAlternate(Player player)
    {
        if (IsEmpty || !StoredItem.IsOperationAvailable(operationType))
            return;

        base.InteractAlternate(player);
        OnAnyCut?.Invoke(this);

        if (CutsToTake < 1f)
            CutsToTake = (StoredItem.GetRecipe(operationType) as ModifyRecipe).TimeToModify;

        if (++CurrentCuts >= CutsToTake)
        {
            StoredItem.DoOperation(operationType);
            ResetCuts();
        }
        else
        {
            ProgressChanged?.Invoke(Progress);
        }
    }
}
