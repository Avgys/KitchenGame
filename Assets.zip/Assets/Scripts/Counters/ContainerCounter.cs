using System;
using UnityEngine;

public class ContainerCounter : BaseCounter
{
    private KitchenObjectState productToSpawn;
    public Sprite Sprite => productToSpawn?.Sprite;
    public event Action Initiated;

    public ProductType ProductType;
    public ProductState ProductState;

    protected override void Start()
    {
        base.Start();
        productToSpawn = AssetCollection.Instance.GetProductState(ProductType, ProductState);
        Initiated?.Invoke();
    }

    public override void Interact(Player source)
    {
        if (source.Node.IsEmpty)
        {
            base.Interact(source);
            var obj = KitchenObject.SpawnProduct(productToSpawn, true);
            source.Node.Push(obj.Node);
        }
        else if (Node.IsEmpty) {
            base.Interact(source);
            var obj = KitchenObject.SpawnProduct(productToSpawn, true);
            Node.Push(obj.Node);
        }
    }

    public override bool TryCombine(ICombinable kitchenObject, out ICombinable result)
    {
        if(IsEmpty)
        {
            var spawnedKo = KitchenObject.SpawnProduct(productToSpawn, true);
            var isCombined = kitchenObject.TryCombine(spawnedKo, out result);

            if (!isCombined)
                Node.Push(spawnedKo.Node);

            return isCombined;
        }
        else
        {
            return base.TryCombine(kitchenObject, out result);
        }        
    }
}