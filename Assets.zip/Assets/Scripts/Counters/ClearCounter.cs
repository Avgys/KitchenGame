public class ClearCounter : BaseCounter
{
    public override void Interact(Player source)
    {
        base.Interact(source);
        Node.SwapChildren(source.Node);
    }
}
