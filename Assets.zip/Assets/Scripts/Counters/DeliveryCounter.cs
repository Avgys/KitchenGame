using System;
using UnityEngine;

public class DeliveryCounter  : ClearCounter
{
    [SerializeField] private ProductType productToDelete;

    public event Action<bool> OnDelivery;

    public override void Interact(Player source)
    {
        base.Interact(source);

        if (Node.FirstItem != null) {
            if (DeliveryManager.Instance.TryDeliverDish(Node.FirstItem.Value)) {
                Node.FirstItem?.Value.DestroySelf();
                OnDelivery?.Invoke(true);
            }
            else
                OnDelivery?.Invoke(false);
        }
    }
}
