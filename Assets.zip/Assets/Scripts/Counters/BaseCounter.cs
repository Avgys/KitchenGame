using System;
using UnityEngine;

public abstract class BaseCounter : MonoBehaviour, IInteractable, ICombinable
{
    private const byte COUNTER_PRIORITY = 0;
    private const byte COUNTER_CAPACITY = 1;
    private static readonly Vector3 CHILD_OFFSET = new Vector3(0, 1.5f, 0);
    public Node<KitchenObject> Node { get; private set; }
    protected KitchenObject StoredItem => Node.FirstItem.Value;
    protected bool IsEmpty => Node.IsEmpty;

    private byte priority => 0;
    public byte HierarchyPriority => priority;
    public Transform Parent => transform;


    protected virtual void Start()
    {
        Node = new(transform, COUNTER_CAPACITY, COUNTER_PRIORITY, CHILD_OFFSET);
    }

    public event Action Interacted;
    public event Action PreppedToInteract;
    public event Action AlternateInteracted;
    public virtual void PrepareToInteract() => PreppedToInteract?.Invoke();
    public virtual void Interact(Player source) => Interacted?.Invoke();
    public virtual void InteractAlternate(Player player) => AlternateInteracted?.Invoke();

    public virtual bool TryCombine(ICombinable kitchenObject, out ICombinable result)
    {
        result = kitchenObject;
        if (Node.IsEmpty) 
            return false;

        return Node.FirstItem.Value.TryCombine(kitchenObject, out result);
    }
}
