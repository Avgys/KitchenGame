using System;
using Unity.VisualScripting;
using UnityEngine;

public class StoveCounter : BaseCounter, IProgress, ITrigger
{
    [SerializeField] private GameObject pan;

    private float currentTime;
    private ModifyRecipe currentRecipe;

    private WaitForSeconds checkTimeout;
    private float progress => currentTime / (currentRecipe?.TimeToModify ?? float.Epsilon);

    public float PlayingSpeed => 1f;



    private const OperationType operationType = OperationType.Cooking;

    private bool cooking = false;
    private bool manualEnable;
    public event Action<float> ProgressChanged;
    public event Action<bool> EnableChanged;
    public event Action<bool> Burning;

    protected override void Start()
    {
        base.Start();
        Node.Offset = new Vector3(0, 1.8f, 0);
        EnableChanged?.Invoke(manualEnable);

        ProgressChanged?.Invoke(progress);

        Burning?.Invoke(false);
        //checkTimeout = new WaitForSeconds(timeToChangeState);        
    }

    private void Update()
    {
        HandleCooking();

        ProgressChanged?.Invoke(progress);
    }

    private void HandleCooking()
    {
        if (IsEmpty)
            return;

        if (!cooking && StoredItem.IsOperationAvailable(operationType))
        {
            currentRecipe = StoredItem.GetRecipe(operationType) as ModifyRecipe;
            cooking = true;
            currentTime = 0;
        }

        if (manualEnable && cooking)
        {
            currentTime += Time.deltaTime;
            if (currentTime > currentRecipe.TimeToModify)
            {
                StoredItem.DoOperation(operationType);
                currentTime = 0;
                cooking = false;
                currentRecipe = null;
            }            
        }

        Burning?.Invoke(manualEnable && cooking && (
                currentRecipe == null || currentRecipe.Output.State == ProductState.Overcooked));
    }

    public override void InteractAlternate(Player player)
    {
        base.InteractAlternate(player);
        manualEnable = !manualEnable;
        EnableChanged?.Invoke(manualEnable);
    }

    public override void Interact(Player source)
    {
        base.Interact(source);

        Node.SwapChildren(source.Node);
        currentTime = 0;
        cooking = false;
        Burning?.Invoke(false);
    }
}
