public enum ProductType
{
    Bread,
    Cabbage,
    Cheese,
    Meat,
    Plate,
    Tomato,
}