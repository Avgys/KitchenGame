
public enum ProductState
{
    Default,
    Cooked,
    Overcooked,
    Sliced,
}