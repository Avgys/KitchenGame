public enum HirachyPriorityes : byte
{
    Player = 0,
    Plate = 1,
    Bread = 2,
    Food = 128
}