public enum OperationType
{
    Slicing,
    Cooking,
    Combining
}