using TMPro;
using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(Image))]
public class IngredientUI : MonoBehaviour
{
    public Image Image;
}
