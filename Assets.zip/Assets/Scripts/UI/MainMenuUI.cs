using UnityEngine;
using UnityEngine.UI;

public class MainMenuUI : MonoBehaviour
{
    [SerializeField] private Button playButton;
    [SerializeField] private Button quitButton;

    void Awake()
    {
        playButton.onClick.AddListener(() =>
            SceneLoader.Load(SceneLoader.Scene.GameScene)
        );

        quitButton.onClick.AddListener(() =>
        {
            Debug.Log("Quit game");
            Application.Quit();
        });

        playButton.Select();
    }
}
