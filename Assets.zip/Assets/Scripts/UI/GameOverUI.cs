using TMPro;
using UnityEngine;

public class GameOverUI : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI dishServedCount;

    private void Start()
    {
        GameManager.Instance.StateChanged += Gamemode_StateChanged;
        gameObject.SetActive(false);
    }

    private void Gamemode_StateChanged(GameManager.State obj)
    {
        if (obj == GameManager.State.GameOver)
        {
            gameObject.SetActive(true);
            dishServedCount.text = DeliveryManager.Instance.TotalDishServed.ToString();
        }
        else
            gameObject.SetActive(false);
    }
}
