using System;
using Unity.Netcode;
using UnityEngine;
using static UnityEngine.InputSystem.InputAction;

public class Player : NetworkBehaviour, ITrigger
{
    [SerializeField] private float Speed;
    [SerializeField] private float SpeedBoost;
    [SerializeField] private float maxInteractDisctance = 0.5f;
    [SerializeField] private float interactZoneScale = 1f;
    [SerializeField] private LayerMask InteractableLayerMask;
    [SerializeField] private Vector3 HoldOffset;

    private Rigidbody rb;

    public float LinearSpeed => rb.linearVelocity.magnitude;

    private IInteractable interactable => interactableInFront;
    private IInteractable interactableInFront;

    public byte Priority => (byte)HirachyPriorityes.Player;

    public Node<KitchenObject> Node { get; private set; }

    public byte HierarchyPriority => 0;

    public float PlayingSpeed => GameInput.Instance.SpeedBoost ? SpeedBoost : 1;

    private const int playerCapacity = 1;

    private RaycastHit lastHitInfo;
    private bool isHitted;

    private Vector3 bodyCenter;
    private const byte PLAYER_PRIORITY = 0;

    public static event Action<Player> PickedUpItem;
    public static event Action<Player> DroppedItem;


    internal static void ResetStatic()
    {
        DroppedItem = null;
        PickedUpItem = null;
    }

    public event Action<bool> EnableChanged;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        Node = new(transform, playerCapacity, PLAYER_PRIORITY, HoldOffset);

        GameInput.Instance.InteractEvent += ActivateInteraction;
        GameInput.Instance.AlternateInteractEvent += ActivateAlternateInteraction;
        GameInput.Instance.Combine += Combine;
        GameInput.Instance.DropEvent += (CallbackContext context) => DropItem(false);
        GameInput.Instance.DropPartEvent += (CallbackContext context) => DropItem(true);
        bodyCenter = new Vector3(0, 0.5f, 0);

        CinemachineScript.Singleton.Follow(transform);
    }

    void DropItem(bool part)
    {
        if (part && (!Node.LastItem?.IsEmpty ?? false))
        {
            Node.LastItem.Value?.Divide();
        }
        else
            Node.Pop(false);

        DroppedItem?.Invoke(this);
    }

    private void ActivateInteraction(CallbackContext context)
    {
        if (interactable == null)
            return;

        if (interactableInFront is KitchenObject ko)
        {
            if (Node.IsEmpty)
                Node.Push(ko.Node);
            else
                Node.ReplaceLastItemWith(ko.Node);
        }

        interactable.Interact(this);

        PickedUpItem?.Invoke(this);
    }

    private void ActivateAlternateInteraction(CallbackContext context)
    {
        if (interactable == null)
            return;

        interactable?.InteractAlternate(this);
    }

    private void Combine(CallbackContext context)
    {
        if (interactableInFront == null || Node.IsEmpty || Node.FirstItem?.Value == null)
            return;

        var holdItemToCombine = Node.FirstItem.Value;
        ICombinable result = null;
        if (interactableInFront is ICombinable combinable)
            holdItemToCombine.TryCombine(combinable, out result);

        var combinedKo = result as KitchenObject;
        if (combinedKo != holdItemToCombine)
            Node.ReplaceLastItemWith(combinedKo.Node);
    }

    void Update()
    {
        HandleMovement();
        HandleInteractions();
    }

    private void HandleInteractions()
    {
        Vector3 p1 = transform.position;
        Vector3 p2 = p1 + bodyCenter * 2;
        isHitted = Physics.CapsuleCast(p1, p2, 0.4f, transform.forward, out lastHitInfo, maxInteractDisctance, InteractableLayerMask);

        if (isHitted && lastHitInfo.transform.TryGetComponent(out IInteractable item))
        {
            interactableInFront = item;
            item.PrepareToInteract();
        }
        else
        {
            interactableInFront = null;
        }
    }

    void OnDrawGizmos()
    {
        Gizmos.color = Color.red;
        float distance = isHitted ? lastHitInfo.distance : maxInteractDisctance;

        Gizmos.DrawRay(transform.position, transform.forward * distance);
        Gizmos.DrawWireSphere(transform.position + transform.forward * distance, interactZoneScale * transform.localScale.x);
    }

    private void HandleMovement()
    {
        var movementVector = GameInput.Instance.MovementVectorNormalized;

        rb.linearVelocity = movementVector
            * Speed
            * (GameInput.Instance.SpeedBoost ? SpeedBoost : 1);

        const float rotateSpeed = 10f;

        if (movementVector != Vector3.zero)
        {
            transform.forward = Vector3.Slerp(
                transform.forward,
                movementVector,
                Time.deltaTime * rotateSpeed);

            EnableChanged?.Invoke(true);
        }
        else
            EnableChanged?.Invoke(false);
    }
}
