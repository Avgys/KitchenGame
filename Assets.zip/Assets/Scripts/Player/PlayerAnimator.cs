using UnityEngine;

public class PlayerAnimator : MonoBehaviour
{
    private Animator animator;
    private Player playerControl;
    private const string WALKING_SPEED = "Speed";
    private const string ANIMATION_SPEED = "AnimationSpeed";

    private float DEFAULT_SPEED = 5f;

    void Start()
    {
        if (transform.parent != null)
            playerControl = transform.parent.GetComponent<Player>();

        animator = GetComponent<Animator>();
    }

    public void Update()
    {
        var playerSpeed = playerControl?.LinearSpeed ?? 0f;
        animator.SetFloat(WALKING_SPEED, playerSpeed);
        animator.SetFloat(ANIMATION_SPEED, playerSpeed / DEFAULT_SPEED);
    }
}
